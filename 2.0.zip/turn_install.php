<?php
	$url="../install/";
?>
<html>
	<title>
		跳转页面
	</title>
	<head>
	<meta charset="utf-8" http-equiv = "refresh" content="5; url =<?php echo $url;?>">
	</head>
	<body>
	未检测到安装锁，说明极有可能未安装主体程序，正在前往安装页面。如果5s内未响应请<a href="../install/">点击此处。</a>
	</body>
</html>