<?php
/*数据库配置*/
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'kzpfmo', //数据库用户名
	'pwd' => 'kzpfmo', //数据库密码
	'dbname' => 'kzpfmo', //数据库名
	'dbqz' => 'tool',//数据表前缀
	'domain'=>'http://jz.jiyijian.com/cloud/',//域名
	'file'=>'upload'//上传目录
);
?>