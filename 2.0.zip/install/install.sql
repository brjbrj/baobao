DROP TABLE IF EXISTS `tool_user`;
create table `tool_user` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`username` varchar(16) NOT NULL,
`password` varchar(32) NOT NULL,
`qq` varchar(16) NOT NULL DEFAULT '123456',
`regdate` datetime DEFAULT NULL,
PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tool_user` VALUES ('0','admin','123456','773867006','2020-3-20 00:00:00');

DROP TABLE IF EXISTS `tool_files`;
create table `tool_files` (
`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
`filepath` text NULL,
`update` datetime DEFAULT NULL,
PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;